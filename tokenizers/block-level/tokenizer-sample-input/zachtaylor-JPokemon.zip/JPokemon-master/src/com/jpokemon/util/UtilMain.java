package com.jpokemon.util;

public class UtilMain {
  public static void main(String[] args) {
    new UtilWindow();
  }
}