package org.jpokemon.interaction;

public interface ActionFactory {
  public Action buildAction(String options);
}