package org.jpokemon.interaction;

public interface RequirementFactory {
  public Requirement buildRequirement(String options);
}